module.exports = require('./dist/jasmine-matchers');
